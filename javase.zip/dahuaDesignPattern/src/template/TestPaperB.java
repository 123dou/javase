package template;

public class TestPaperB extends TestPaper{
     public String answer1() {
    	 return "a";
     }

	@Override
	public String answer2() {
		return "d";
	}

	@Override
	public String answer3() {
		return "e";
	}
}
