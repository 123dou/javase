package simpleFactory;

public class OperationMul extends Operation{

	@Override
	public double getResult() {
		return number1 * number2;
	}

}
