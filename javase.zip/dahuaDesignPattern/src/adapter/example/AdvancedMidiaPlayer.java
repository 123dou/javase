package adapter.example;

public interface AdvancedMidiaPlayer {
    void playVlc(String fileName);
    void playMp4(String fileName);
}
