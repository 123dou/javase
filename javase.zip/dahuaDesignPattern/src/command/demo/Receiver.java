package command.demo;

public class Receiver {
    void action() {
    	System.out.println("执行请求");
    }
}
