package dynamicProxy;

public interface IUserService {
	/**
	 * 目标方法
	 */
    void update();
    void insert();
}
