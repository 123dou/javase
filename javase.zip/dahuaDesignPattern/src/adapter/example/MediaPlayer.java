package adapter.example;

public interface MediaPlayer {
    void paly(String autoType, String fileName);
}
