package streamExa;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Example {


    @Test
    public void testReduction() {
        var arr = new int[]{1, 2, 3};
        int sum = Arrays.stream(arr).reduce(0, (x, y) -> x + y);
        OptionalDouble i = Arrays.stream(arr).average();
        System.out.println(i + " " + sum);
    }

    @Test
    public void testPeek() {
        List<String> stream = Stream.of("abc", "ad", "vdds", "a", "dfadfa", "daf")
                .filter(x -> x.length() >= 3)
                .map(x -> x.toUpperCase())
                .collect(Collectors.toList());
        System.out.println(stream);
    }

    @Test
    public void testSort() {
        var stream = IntStream.generate(() -> new Random().nextInt()).limit(10).toArray();
        System.out.println(Arrays.toString(stream));
        int[] ints = IntStream.of(stream).sorted().toArray();
        System.out.println(Arrays.toString(ints));
        System.out.println(Arrays.toString(stream));
    }
}
