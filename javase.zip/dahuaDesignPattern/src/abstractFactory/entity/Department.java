package abstractFactory.entity;

public class Department {
    private String deptName;
    private Integer deptNum;
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Integer getDeptNum() {
		return deptNum;
	}
	public void setDeptNum(Integer deptNum) {
		this.deptNum = deptNum;
	}
}
