package clhAndMsc;

public interface Lock {
    void lock();
    void unlock();
}
