package adapter.demo;
/**
 * 需要适配的类
 * @author dou
 *
 */
public class Adaptee {
    public void specificRequest() {
    	System.out.println("特殊请求");
    }
}
