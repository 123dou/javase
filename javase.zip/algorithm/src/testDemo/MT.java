package testDemo;

import java.util.EnumSet;

public class MT {
    public enum Person {
        MAN, WOMAN;
    }
    public static void main(String[] args) {
        boolean matches = String.valueOf('a').matches("[a-z]");
        System.out.println(matches);
        EnumSet<Person> man = EnumSet.of(Person.MAN, Person.WOMAN);

    }

}
