package proxy;
/**
 * 抽像出来的总接口,代理跟实际对像都实现这个接口
 * @author dou
 *
 */
public interface IGiveGift {
    void giveDolls();
    void giveFlowers();
    void giveChocolate();
}
