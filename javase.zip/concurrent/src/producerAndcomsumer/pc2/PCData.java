package producerAndcomsumer.pc2;


public final class PCData {
    public final int DATA;

    public PCData(int data) {
        this.DATA = data;
    }

    public int getDATA() {
        return DATA;
    }

    public String toString() {
        return "data: " + DATA;
    }
}
