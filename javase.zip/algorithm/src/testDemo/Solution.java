package testDemo;

import java.util.Scanner;

public class Solution {
    private static int min = Integer.MAX_VALUE;

    public static void main(String[] args) {
        int a = 1;
        System.out.println("ni hao");
    }


}