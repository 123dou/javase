package bridge;

public class Contact implements APK{

	@Override
	public void install() {
        System.out.println("安装通讯录");		
	}

}
