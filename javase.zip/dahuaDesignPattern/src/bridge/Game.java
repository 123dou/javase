package bridge;

public class Game implements APK{

	@Override
	public void install() {
        System.out.println("安装游戏");		
	}

}
