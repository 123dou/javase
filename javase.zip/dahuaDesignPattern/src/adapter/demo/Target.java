package adapter.demo;
/**
 * 这是客户所期待的接口,目标可以是具体的或抽像的类
 * @author dou
 *
 */
public class Target {
    public void request() {
    	System.out.println("谱通请求");
    }
}
