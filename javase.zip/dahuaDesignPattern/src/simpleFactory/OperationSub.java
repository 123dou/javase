package simpleFactory;

public class OperationSub extends Operation {

	@Override
	public double getResult() {
		return number1 - number2;
	}

}
