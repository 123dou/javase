package proxy;

public class SchoolGirl {
    private String name;
    public SchoolGirl(String name) {
    	this.name = name;
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
