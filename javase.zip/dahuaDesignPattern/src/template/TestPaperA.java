package template;

public class TestPaperA extends TestPaper{
     public String answer1() {
    	 return "b";
     }

	@Override
	public String answer2() {
		return "c";
	}

	@Override
	public String answer3() {
		return "d";
	}
}
