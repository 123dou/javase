package observer;
//观察者需要实现的接口,被观察可以直接调用的方法
public interface IObserver {
    void update();
}
