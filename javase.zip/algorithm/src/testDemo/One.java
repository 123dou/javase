package testDemo;

import leetcode.TreeAndList.TreeNode;

public class One {
    public TreeNode invertTree(TreeNode root) {
        if (root == null) {
            return null;
        }
        TreeNode left = invertTree(root.left);
        TreeNode right = invertTree(root.right);
        root.left = right;
        root.right = left;
        return root;
    }

    //test
    public static void main(String[] args) {
        System.out.println(~1);
        System.out.println(Integer.toBinaryString(-2));
        System.out.println(Integer.toBinaryString(~((~-2) | 4)));
    }

}
