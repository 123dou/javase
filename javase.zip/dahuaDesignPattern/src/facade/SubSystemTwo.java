package facade;

public class SubSystemTwo {
	public void methodTwo() {
    	System.out.println("子系统方法Two");
    }
}
