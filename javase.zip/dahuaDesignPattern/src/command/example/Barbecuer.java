package command.example;

public class Barbecuer {
    public void BakeMutton() {
    	System.out.println("烤羊肉");
    }
    public void BakeChickenWing() {
    	System.out.println("烤鸡翅");
    }
}
